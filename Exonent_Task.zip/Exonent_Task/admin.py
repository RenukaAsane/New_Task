# -*- coding: utf-8 -*-
"""
Created on Sat Dec 28 21:01:08 2024

@author: Admin
"""

from django.contrib import admin
from .models import CustomUser, Student, Course

@admin.register(CustomUser)
class CustomUserAdmin(admin.ModelAdmin):
    list_display = ('username', 'email')
    search_fields = ('username', 'email')

@admin.register(Student)
class StudentAdmin(admin.ModelAdmin):
    list_display = ('user', 'grade')
    search_fields = ('user__username', 'grade')

@admin.register(Course)
class CourseAdmin(admin.ModelAdmin):
    list_display = ('name',)
    search_fields = ('name',)
