# -*- coding: utf-8 -*-
"""
Created on Sat Dec 28 20:58:42 2024

@author: Admin
"""

from django.db import models
from django.contrib.auth.models import AbstractUser

class CustomUser(AbstractUser):
    email = models.EmailField(unique=True)
    REQUIRED_FIELDS = ['email']

class Student(models.Model):
    user = models.OneToOneField(CustomUser, on_delete=models.CASCADE)
    grade = models.CharField(max_length=50)

class Course(models.Model):
    name = models.CharField(max_length=255)
    students = models.ManyToManyField(Student, related_name='courses')
