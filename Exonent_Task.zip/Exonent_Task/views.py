# -*- coding: utf-8 -*-
"""
Created on Sat Dec 28 21:00:33 2024

@author: Admin
"""

from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from rest_framework.permissions import IsAuthenticated
from .models import CustomUser, Course
from .serializers import UserSerializer, CourseSerializer
from rest_framework_simplejwt.tokens import RefreshToken
from rest_framework.parsers import FileUploadParser
from django.core.cache import cache
from celery import shared_task

class RegisterView(APIView):
    def post(self, request):
        serializer = UserSerializer(data=request.data)
        if serializer.is_valid():
            user = serializer.save()
            send_welcome_email.delay(user.id)  # Trigger Celery task
            refresh = RefreshToken.for_user(user)
            return Response({
                'refresh': str(refresh),
                'access': str(refresh.access_token),
            }, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

class CourseView(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request):
        courses = Course.objects.prefetch_related('students').all()
        serializer = CourseSerializer(courses, many=True)
        return Response(serializer.data)

    def post(self, request):
        serializer = CourseSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

class FileUploadView(APIView):
    parser_classes = [FileUploadParser]

    def post(self, request):
        file = request.data.get('file')
        if not file:
            return Response({'error': 'No file provided'}, status=status.HTTP_400_BAD_REQUEST)

        with open(f'temp/{file.name}', 'wb+') as destination:
            for chunk in file.chunks():
                destination.write(chunk)

        process_uploaded_file.delay(file.name)  # Trigger Celery task
        return Response({'message': 'File uploaded successfully'}, status=status.HTTP_200_OK)

class CacheExampleView(APIView):
    def get(self, request):
        data = cache.get('example_data')
        if not data:
            data = {'message': 'This is cached data!'}
            cache.set('example_data', data, timeout=300)
        return Response(data)

@shared_task
def send_welcome_email(user_id):
    user = CustomUser.objects.get(id=user_id)
    print(f"Welcome email sent to {user.email}")

@shared_task
def process_uploaded_file(filename):
    print(f'Processing file: {filename}')
